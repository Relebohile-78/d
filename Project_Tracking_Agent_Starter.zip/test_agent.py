import unittest
from datetime import date
from app import assess, report, validate, retrieve
class Checks(unittest.TestCase):
    def row(self,**kwargs):
        r=dict(id='T1',task='Task',owner='Lead',due='2026-10-20',progress=20,critical=0,blocked=0,updated='2026-10-09');r.update(kwargs);return r
    def test_status_rules(self):
        d=date(2026,10,9)
        for changes,status in [({},'Green'),({'due':'2026-10-08'},'Amber'),({'due':'2026-10-08','critical':1},'Red'),({'updated':'2026-09-01'},'Unknown'),({'progress':100,'blocked':1},'Green'),({'due':'2026-10-09'},'Amber')]:
            self.assertEqual(assess(self.row(**changes),d)[0],status)
    def test_overall(self):
        self.assertIn('Overall: Unknown',report([],date(2026,10,9)))
        self.assertIn('Overall: Red',report([self.row(critical=1,blocked=1),self.row(updated='2026-09-01')],date(2026,10,9)))
    def test_validation(self):
        with self.assertRaises(ValueError):validate([self.row(progress=120)])
        with self.assertRaises(ValueError):validate([self.row(),self.row()])
        with self.assertRaises(ValueError):validate([self.row(due='bad')])
    def test_retrieval(self):
        self.assertTrue(retrieve('sponsor requirements'))
        self.assertEqual(retrieve('zzzznonexistent'),[])
if __name__=='__main__':unittest.main()
