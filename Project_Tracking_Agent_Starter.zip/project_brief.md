# Project brief
Project name:
Sponsor:
Project manager:
Objective and measurable success criteria:
Approved scope and exclusions:
Start date:
Target finish date:
Milestones and acceptance criteria:
Approved budget and actual spending (if applicable):
Dependencies:
Risks, likelihood, impact, mitigation and owner:
Reporting frequency:
Approved status rules:
Baseline version and approval date:
