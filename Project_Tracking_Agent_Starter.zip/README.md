# Local Project Agent — starter edition

## Try the app
1. Install Python 3.10 or later on your computer.
2. Extract this ZIP into a folder you control.
3. Open a terminal in that folder and run `python app.py` (Windows may use `py app.py`; macOS/Linux may use `python3 app.py`).
4. Open http://127.0.0.1:8765 in your browser.
5. Click **Add demo tasks**, then **Generate report**. The demo should report Red because a critical task is blocked and overdue.
6. Import your own CSV using `tasks_template.csv`. Edit the CSV in a text editor or spreadsheet application, save it as UTF-8 CSV, and import again to update IDs.

No Python packages are required. Stop with Ctrl+C. Data persists in project.db next to app.py; copy that database and the knowledge_base folder for backups. Use a separate extracted folder for each project. Demo tasks remain until you start with a fresh database; the starter does not provide deletion or an in-browser task editor. Import updates existing IDs and adds new IDs; it does not remove omitted rows. Each import is stored in an audit history table.

## Documents and prompts
Put UTF-8 `.txt` or `.md` files in knowledge_base. Word/PDF are not supported directly in this starter; export their text first and keep page labels if you need page references. Retrieval searches overlapping text passages by query-word overlap. It is basic lexical retrieval, not a vector embedding index. Without AI, Ask returns the current rule-based report plus matching passages. This mode does not interpret arbitrary natural-language requests.

## Optional local AI
Install Ollama separately and download a LOCAL model compatible with your computer. Find the exact installed model name using `ollama list`. Set OLLAMA_MODEL before launching:

Windows PowerShell:
```powershell
$env:OLLAMA_MODEL="your-installed-local-model"
py app.py
```
macOS/Linux:
```bash
export OLLAMA_MODEL="your-installed-local-model"
python3 app.py
```
Start Ollama and check **Use local Ollama model** in the app. The app calls only http://127.0.0.1:11434/api/chat; select a local model rather than an Ollama cloud model. Installation/model downloads require internet; normal use with a downloaded local model can run offline. Responses include retrieved evidence, but generated citations and interpretations still require review. The model connection has not been exercised with a live model in this delivery.

## Tracking rules
Dates use your computer's local date. Past due means strictly earlier than today. Critical/blocked values are 0 or 1; progress is an integer from 0 to 100. See AGENT_INSTRUCTIONS.md for the complete starter rules. Due within seven days is intentionally conservative. These rules are fixed in assess() and report() if you wish to customise them. Completed means reported complete, not accepted. Known risks determine status before freshness; inspect dates even on Red/Amber/Green completed rows.

## Try the instruction/template version
Copy AGENT_INSTRUCTIONS.md into your preferred assistant's instructions. Provide the completed task register, project_brief.md, weekly_update.md and your supporting documents. Use the example prompts. This version works independently of the app. The app tracks tasks and uses document retrieval; the brief and weekly update templates are contextual documents, not structured fields automatically parsed into tasks.

## Scope
This is a single-user local prototype, not a production multi-user service. It binds to your computer's loopback address. Keep it local. It does not automatically monitor your folders, schedule reports, send messages, verify deliverables, track budgets or change task records from chat. Updates must be imported explicitly. Model answers cannot execute actions.

API reference: https://github.com/ollama/ollama/blob/main/docs/api.md
